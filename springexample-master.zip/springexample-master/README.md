http://devops:3965ad3bebaea5aec73b51e5e6721447@ec2-52-14-5-48.us-east-2.compute.amazonaws.com:8080/job/test_maven/build?token=hsfhasgdfshfashjvadhj




    mvn archetype:generate -DgroupId=com.mycompany.app -DartifactId=my-app -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false
